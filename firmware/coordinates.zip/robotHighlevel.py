#this code controls the robot and converts high level commands (where to go)
#into low level commands (move to this co-ordinate)
#from __future__ import division
import time
import math as m
import serial
import random

#from stageCalibration import *

def dc(something):
    """wrapper for deep copy"""
    return c.deepcopy(something)

class Robot:
    def __init__(self,serialPort,baudrate,timeout=200):
        """opens a serial channel and begins communication"""
        self.robolink = serial.Serial(serialPort, baudrate, timeout=200)
        time.sleep(3)
        self.modx = 0.0
        self.mody = 0.0
        self.modz = 0.0
        self.stageposx = 0.0
        self.stageposy = 0.0
        self.homeNow()
        self.uLpermm = 7.0
        
    def homeNow(self):
        self.arbGcode("G28 Z0")
        self.arbGcode("G1 Z60")
        self.arbGcode("G28 X0")
        self.arbGcode("G28 Y0")
        self.arbGcode("G28 Z0")
        self.arbGcode("G1 Z60")
        
    def setOffset(self,stagecoords):
        """sets a stage offset for stage co-ordination"""
        self.stageposx = stagecoords[0]
        self.stageposy = stagecoords[1]
        
    def gotoWell(self,welldef,well,feedrate=1000):
        """tells the robot to move to the top coordinate of
        a well"""
        curpos = self.getCoords();
        welldef.setOffset([self.stageposx,self.stageposy])
        XYgoal = welldef.wellPos(well)
        Zgoal = welldef.zposTOP

        if(curpos[2] < Zgoal):
            self.makeMove([None,None,Zgoal,None],feedrate)
        self.makeMove([XYgoal[0],XYgoal[1],None,None],feedrate)
        self.makeMove([None,None,Zgoal,None],feedrate)
        
    def aspirate(self,amount_uL,feedrate= 300):
        """how many microliters to suck in"""
        amount_mm = amount_uL/self.uLpermm
        currentPosition = self.getCoords()[3]
        self.arbGcode("G1 E{} F{}".format(currentPosition-amount_mm,feedrate))
    
    def dispense(self,amount_uL,feedrate=300):
        """how many microliters to spit out"""
        self.aspirate(-amount_uL,feedrate)
    def gotoBottom(self,microwell,feedrate=1000):
        self.makeMove([None,None,microwell.zposBOTTOM],feedrate)
    def gotoTop(self,microwell,feedrate=1000):
        self.makeMove([None,None,microwell.zposTOP],feedrate)
    def makeMove(self, coords,feedrate=1000):
        """issues a gcode command to the robot, waits for an 'ok' before proceeding"""
        gcode = "G1{}\n"
        xyz = ""
        dimorder = [" X{}"," Y{}"," Z{}"," E{}"," F{}"]
        for el in range(len(coords)):
            if coords[el] != None:
                if(coords[el]<0.00001):
                    coords[el] = 0
                xyz+=dimorder[el].format(coords[el])
        if(feedrate != 0):
            xyz+=dimorder[4].format(feedrate)
        gcode = gcode.format(xyz)
        #print "SENDING: {}".format(gcode)
        self.robolink.write(gcode)
        
        self.readComm()
    
    def arbGcode(self,code):
        """sends any arbitrary gcode, and returns the result"""
        self.robolink.write(code+"\n")
        return self.readComm()
    
    def readComm(self):
        """reads everything until 'OK' from the serial and returns it"""
        retline = ""
        while True:
            response = self.robolink.readline()
            if 'ok' in response.lower():
                break
            retline+=response
        print retline
        return retline
    
    def getCoords(self):
        """issues M114 command and returns a list of coords"""
        outcoord = [0,0,0,0] #x,y,z,e
        coords = self.arbGcode("M114")
        coords=coords.replace("X: ", "X:")
        cspl = coords.split()
        cspl = cspl[:cspl.index('Count')]#+1:]
        for words in cspl:
            #print words
            if words[0] == "X":
                outcoord[0] = float(words[2:])
            if words[0] == "Y":
                outcoord[1] = float(words[2:])
            if words[0] == "Z":
                outcoord[2] = float(words[2:])
            if words[0] == "E":
                outcoord[3] = float(words[2:])
        return outcoord
        #process it here somehow
        
    def hitEndstops(self):
        """issues the endstop hit check command and returns a list of true, false"""
        ends = self.arbGcode("M119")
        outlist = [0,0,0,0]
        espl = ends.split("\n")
        espl = espl[1:]
        for eind in range(len(espl)):
            if("TRIGGERED" in espl[eind]):
                outlist[eind] = 1
        return outlist
    
    def endStep(self, startcoords, endcoords,step, endstopcheck=[0,0,1,0],feed = 300,wait = 0.1):
        """goes from the startcoords to the endcoords one step at a time, checking
        endstop hit along the way"""
        movelist = self.intermediatePoints(startcoords,endcoords,step)
        curpos = startcoords
        prevpos = startcoords
        hitsomething = False
        print "moving fast!"
        for move in movelist: #move forward until we touch something
            self.makeMove(move,feed)
            time.sleep(wait)
            prevpos = dc(curpos)
            curpos = dc(move)
            endstop = self.hitEndstops()
            for end in range(len(endstopcheck)):
                if(endstopcheck[end] and endstop[end]):
                    hitsomething=True
                    print "we hit something!"
                    break
            if(hitsomething):
                break
        if(not hitsomething): #we didnt hit anything!!
            return False, endcoords
        #now, move back until we no longer touch that thing
        newmovelist = movelist[:movelist.index(curpos)][::-1] #reversed list, starting from the hit pos
        notouch = startcoords
        countoff  = 5
        print "move back!"
        for move in newmovelist:
            self.makeMove(move,feed)
            time.sleep(wait)
            notouch = dc(move)
            endstop = self.hitEndstops()
            for end in range(len(endstopcheck)):
                if(endstopcheck[end] and (not endstop[end])):
                    hitsomething = False
                    break
            if(not hitsomething):
                countoff-=1 #this means we move a set amount of steps farther than the edge
                if(countoff <= 0):
                    break
        #move again, with a smaller step
        lastmovelist = self.intermediatePoints(notouch,endcoords,0.01)
        print "final approach!"
        #hitsomething = False
        for move in lastmovelist: #move forward until we touch something
            self.makeMove(move,feed)
            time.sleep(wait)
            prevpos = dc(curpos)
            curpos = dc(move)
            endstop = self.hitEndstops()
            for end in range(len(endstopcheck)):
                if(endstopcheck[end] and endstop[end]):
                    print "HIT!"
                    hitsomething = True
                    break
            if(hitsomething):
                break
        actualcoords = self.getCoords()
        return True, actualcoords
    
        
    def intermediatePoints(self,startcoords,endcoords,step):
        """makes a list of intermediate points between start and end with a distance of step"""
        stepx = endcoords[0]-startcoords[0]
        stepy = endcoords[1]-startcoords[1]
        stepz = endcoords[2]-startcoords[2]
        r, theta, phi = self.cart2sph(stepx,stepy,stepz)
        dx, dy, dz = self.sph2cart(step,theta,phi)
        numberofsteps = int(r/step) #the number of steps we need to take!
        clist = [startcoords]
        #print "theta"+str(theta)
        #print "phi"+str(phi)
        
        for i in range(numberofsteps):
            newx = "%.8G"%(clist[-1][0]+dx)
            newy = "%.8G"%(clist[-1][1]+dy)
            newz = "%.8G"%(clist[-1][2]+dz)
            newc = [float(newx),float(newy) ,float(newz) ,endcoords[3]]
            clist+=[newc]
        #print clist
        return clist
    
    def cart2sph(self,x,y,z):
        """convert cartesian xyz to spherical r, theta phi"""
        XsqPlusYsq = x**2 + y**2
        r = m.sqrt(XsqPlusYsq + z**2)               # r
        elev = m.atan2(z,m.sqrt(XsqPlusYsq))     # theta
        elev = m.pi/2-elev
        az = m.atan2(y,x)                       # phi
        #az = m.pi/2-az
        return r, elev, az
    
    def sph2cart(self,r, elev, az):
        """convert spherical r, theta, phi to cartesian x y z"""
        #elev = 180/m.pi*elev
        #az = 180/m.pi*az
        x=r*m.sin(elev)*m.cos(az)
        y=r*m.sin(elev)*m.sin(az)
        z=r*m.cos(elev)
        return x,y,z

    def scanLine(self, scanPoints,scanDelta,feed=300,step=0.1,wait=0.1,endstopcheck = [0,0,1,0]):
        """goes along a set of points, scanning with the endstep function"""
        retpoints = []
        for pind in range(len(scanPoints)):
            scanpoint = scanPoints[pind]
            deltapoint = scanDelta[pind]
            endpoint = [scanpoint[0]+deltapoint[0],scanpoint[1]+deltapoint[1],scanpoint[2]+deltapoint[2],0]
    
            self.makeMove([None,None,70,None],feedrate=feed)
            self.makeMove([scanpoint[0],scanpoint[1],None,None],feedrate=feed)
            self.makeMove(scanpoint,feedrate=feed)
            trash,retpoint = self.endStep(scanpoint,endpoint,step=step,endstopcheck=endstopcheck,feed = feed,wait=wait)
            self.makeMove(scanpoint,feedrate=feed)
            retpoints+=[retpoint]
        return retpoints
    def turnOff(self):
        self.robolink.close()
    
    
    
class Microwell:
    def __init__(self,platedef,offset = [0,0]):
        """plate definition: [<distance in X between wells>,
        <distance in Y between wells>, <X pos of first well>,
        <Y pos of first well>, <Z pos of first well, top>,
        <Z pos of first well, bottom>, <wells in X>, <wells in Y>]"""
        self.xspace = platedef[0]
        self.yspace = platedef[1]
        self.xpos = platedef[2] #Closest to origin
        self.ypos = platedef[3] #Closest to origin
        self.zposTOP = platedef[4]
        self.zposBOTTOM = platedef[5]
        self.xwells = platedef[6]
        self.ywells = platedef[7]
        self.offsetX = offset[0]
        self.offsetY = offset[1]
    def wellPos(self,well):
        """well is a string, like "A1" or "G7
        ===> Y
        || [H G F E D C B A ]
        ||                   1
        \/                   2
        X                    3
         etc
         """
        alph = 'abcdefghijklmnopqrstuvwxyz'
        yind = alph.index(well[0].lower())
        xind = self.xwells-(int(well[1:]))
        xval = self.xpos+self.offsetX+xind*self.xspace
        yval = self.ypos+self.offsetY+yind*self.yspace
        return (xval,yval)
    
    def setOffset(self,offset):
        self.offsetX = offset[0]
        self.offsetY = offset[1]
    
PLATEDEF_384WELL=[4.5,4.5,39.0,44.0,14, 3.4,24,16,0,0]
PLATEDEF_VIALRACK =[15.85,13.9,126.4,136.6,47.1,12,4,2,0,0]
if __name__ == '__main__':
    pipetBot = Robot('COM8',250000)
    plate384 = Microwell(PLATEDEF_384WELL)
    vialrack = Microwell(PLATEDEF_VIALRACK)
    pipetBot.dispense(300)
    pipetBot.arbGcode("G4 S10") #Wait 10s
    pipetBot.aspirate(300)
    pipetBot.arbGcode("G4 S10") #Wait 10s
    pipetBot.homeNow()
    pipetBot.turnOff()
    bobdole()
    ''

    """
    pipetBot.gotoWell(vialrack,"B4")
    pipetBot.gotoBottom(vialrack)
    pipetBot.aspirate(300)
    #pipetBot.readComm()
    pipetBot.arbGcode("G4 S20") #Wait 10s
    pipetBot.gotoTop(vialrack)
    """
    
    volume = 100
    deadvolume = 300
    for well in ['F13', 'G14', 'H15']:
        pipetBot.gotoWell(vialrack,"B4")
        pipetBot.gotoBottom(vialrack)
        pipetBot.aspirate(volume)
        #pipetBot.readComm()
        pipetBot.arbGcode("G4 S20") #Wait 10s
        pipetBot.gotoTop(vialrack)
        pipetBot.gotoWell(plate384,well)
        pipetBot.gotoBottom(plate384)
        pipetBot.arbGcode("G4 S1") #Wait 10s
        pipetBot.dispense(deadvolume + volume)
        pipetBot.arbGcode("G4 S10") #Wait 10s
        pipetBot.gotoTop(plate384)
        pipetBot.aspirate(deadvolume)

    #pipetBot.aspirate(150)



    pipetBot.homeNow()
    pipetBot.turnOff()
    
#'''
